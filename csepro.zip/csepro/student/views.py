from django.shortcuts import render

from rest_framework import viewsets

from .models import (
    Student,
    StudentMarks,
    StudentLocation,
    StudentBusRoute,
    StudentPlayground,
)

from .serializers import (
    StudentSerializer,
    StudentMarksSerializer,
    StudentLocationSerializer,
    StudentBusRouteSerializer,
    StudentPlaygroundSerializer,
)


class StudentViewSet(viewsets.ModelViewSet):
    queryset = Student.objects.all()
    serializer_class = StudentSerializer


class StudentMarksViewSet(viewsets.ModelViewSet):
    queryset = StudentMarks.objects.all()
    serializer_class = StudentMarksSerializer


class StudentLocationViewSet(viewsets.ModelViewSet):
    queryset = StudentLocation.objects.all()
    serializer_class = StudentLocationSerializer


class StudentBusRouteViewSet(viewsets.ModelViewSet):
    queryset = StudentBusRoute.objects.all()
    serializer_class = StudentBusRouteSerializer


class StudentPlaygroundViewSet(viewsets.ModelViewSet):
    queryset = StudentPlayground.objects.all()
    serializer_class = StudentPlaygroundSerializer



import cv2
import numpy as np

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status


class CameraAPIView(APIView):

    # def post(self, request):
    #
    #     if 'photo' not in request.FILES:
    #         return Response(
    #             {"error": "Photo is required"},
    #             status=status.HTTP_400_BAD_REQUEST
    #         )
    #
    #     uploaded_file = request.FILES['photo']
    #
    #     # Read uploaded image
    #     image_bytes = uploaded_file.read()
    #
    #     # Convert bytes to NumPy array
    #     np_array = np.frombuffer(image_bytes, np.uint8)
    #
    #     # Convert to OpenCV image
    #     image = cv2.imdecode(np_array, cv2.IMREAD_COLOR)
    #
    #     if image is None:
    #         return Response(
    #             {"error": "Invalid image"},
    #             status=status.HTTP_400_BAD_REQUEST
    #         )
    #
    #     # -----------------------------
    #     # OpenCV processing
    #     # -----------------------------
    #
    #     # Convert to grayscale
    #     gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    #
    #     # Convert grayscale back to 3-channel image
    #     processed = cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)
    #
    #     # Encode processed image
    #     success, encoded_image = cv2.imencode(
    #         '.jpg',
    #         processed
    #     )
    #
    #     if not success:
    #         return Response(
    #             {"error": "Image processing failed"},
    #             status=status.HTTP_500_INTERNAL_SERVER_ERROR
    #         )
    #
    #     # Return image
    #     from django.http import HttpResponse
    #
    #     return HttpResponse(
    #         encoded_image.tobytes(),
    #         content_type='image/jpeg'
    #     )

    def post(self, request):

        if 'photo' not in request.FILES:
            return Response(
                {"error": "Photo is required"},
                status=status.HTTP_400_BAD_REQUEST
            )

        uploaded_file = request.FILES['photo']

        # Read image
        image_bytes = uploaded_file.read()

        # Convert bytes to NumPy array
        np_array = np.frombuffer(image_bytes, np.uint8)

        # Decode image
        image = cv2.imdecode(
            np_array,
            cv2.IMREAD_COLOR
        )

        if image is None:
            return Response(
                {"error": "Invalid image"},
                status=status.HTTP_400_BAD_REQUEST
            )

        # -------------------------
        # OpenCV processing
        # -------------------------

        # 1. Convert to grayscale
        gray = cv2.cvtColor(
            image,
            cv2.COLOR_BGR2GRAY
        )

        # 2. Reduce noise
        blur = cv2.GaussianBlur(
            gray,
            (5, 5),
            0
        )

        # 3. Detect edges
        edges = cv2.Canny(
            blur,
            50,
            150
        )

        # -------------------------
        # Return image
        # -------------------------

        success, encoded_image = cv2.imencode(
            '.jpg',
            edges
        )

        if not success:
            return Response(
                {"error": "Image processing failed"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
        from django.http import HttpResponse
        return HttpResponse(
            encoded_image.tobytes(),
            content_type='image/jpeg'
        )