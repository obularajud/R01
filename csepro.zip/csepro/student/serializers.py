from rest_framework import serializers
from rest_framework_gis.serializers import GeoFeatureModelSerializer

from .models import (
    Student,
    StudentMarks,
    StudentLocation,
    StudentBusRoute,
    StudentPlayground,
)


# Normal model
class StudentSerializer(serializers.ModelSerializer):

    class Meta:
        model = Student
        fields = '__all__'
        # fields = [
        #     'id',
        #     'name',
        #     'roll_number',
        # ]


# Normal model
class StudentMarksSerializer(serializers.ModelSerializer):

    class Meta:
        model = StudentMarks
        fields = [
            'id',
            'student',
            'subject',
            'marks',
        ]


# Point GIS model
class StudentLocationSerializer(GeoFeatureModelSerializer):

    class Meta:
        model = StudentLocation
        geo_field = 'location'
        fields = [
            'id',
            'student',
            'location',
        ]


# LineString GIS model
class StudentBusRouteSerializer(GeoFeatureModelSerializer):

    class Meta:
        model = StudentBusRoute
        geo_field = 'route'
        fields = [
            'id',
            'student',
            'bus_number',
            'route',
        ]


# Polygon GIS model
class StudentPlaygroundSerializer(GeoFeatureModelSerializer):

    class Meta:
        model = StudentPlayground
        geo_field = 'playground'
        fields = [
            'id',
            'student',
            'game_name',
            'playground',
        ]