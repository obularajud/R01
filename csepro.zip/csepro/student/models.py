from django.contrib.gis.db import models


class Student(models.Model):
    name = models.CharField(max_length=100)
    roll_number = models.CharField(max_length=20, unique=True)
    photo = models.ImageField(
        upload_to="student_photos/",
        null=True,
        blank=True,
        default="student_photos/default.jpg"
    )

    def __str__(self):
        return f"{self.roll_number} - {self.name}"



class StudentMarks(models.Model):
    student = models.ForeignKey(
        Student,
        on_delete=models.CASCADE,
        related_name='marks'
    )
    subject = models.CharField(max_length=100)
    marks = models.PositiveIntegerField()

    def __str__(self):
        return f"{self.student.roll_number} - {self.subject} - {self.marks}"


class StudentDocument(models.Model):
    student = models.ForeignKey(Student,on_delete=models.CASCADE,related_name="documents")
    document_name = models.CharField(max_length=100)
    document = models.FileField(upload_to="student_documents/")

    def __str__(self):
        return f"{self.student.roll_number} - {self.document_name}"

    def extension(self):
        name, extension = os.path.splitext(self.document.name)
        print(extension,name)
        if extension == '.pdf':
            return 'pdf'
        if extension == '.doc':
            return 'word'
        if extension == '.jpg':
            return 'img'
        return 'other'

# 1. Student Location - Point
class StudentLocation(models.Model):
    student = models.OneToOneField(
        Student,
        on_delete=models.CASCADE,
        related_name='location'
    )

    location = models.PointField(
        geography=True
    )

    def __str__(self):
        return f"{self.student.name} - Location"


# 2. Student Bus Route - Line
class StudentBusRoute(models.Model):
    student = models.ForeignKey(
        Student,
        on_delete=models.CASCADE,
        related_name='bus_routes'
    )

    route = models.LineStringField(
        geography=True
    )

    bus_number = models.CharField(
        max_length=20
    )

    def __str__(self):
        return f"{self.student.name} - Bus {self.bus_number}"


# 3. Student Playground - Polygon
class StudentPlayground(models.Model):
    student = models.ForeignKey(
        Student,
        on_delete=models.CASCADE,
        related_name='playgrounds'
    )

    playground = models.PolygonField(
        geography=True
    )

    game_name = models.CharField(
        max_length=100
    )

    def __str__(self):
        return f"{self.student.name} - {self.game_name}"