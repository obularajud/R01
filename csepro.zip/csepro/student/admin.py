from django.contrib import admin
from leaflet.admin import LeafletGeoAdmin

from .models import (
    Student,
    StudentMarks,
    StudentLocation,
    StudentBusRoute,
    StudentPlayground,
    StudentDocument,
)


# Standard non-spatial model
@admin.register(Student)
class StudentAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'roll_number')
    search_fields = ('name', 'roll_number')


# Standard non-spatial model
@admin.register(StudentMarks)
class StudentMarksAdmin(admin.ModelAdmin):
    list_display = ('id', 'student', 'subject', 'marks')
    list_filter = ('subject',)
    search_fields = (
        'student__name',
        'student__roll_number',
        'subject',
    )


# Geo model: PointField
@admin.register(StudentLocation)
class StudentLocationAdmin(LeafletGeoAdmin):
    list_display = (
        'id',
        'student',
        'location',
    )
    search_fields = (
        'student__name',
        'student__roll_number',
    )


# Geo model: LineStringField
@admin.register(StudentBusRoute)
class StudentBusRouteAdmin(LeafletGeoAdmin):
    list_display = (
        'id',
        'student',
        'bus_number',
        'route',
    )
    list_filter = ('bus_number',)
    search_fields = (
        'student__name',
        'student__roll_number',
        'bus_number',
    )


# Geo model: PolygonField
@admin.register(StudentPlayground)
class StudentPlaygroundAdmin(LeafletGeoAdmin):
    list_display = (
        'id',
        'student',
        'game_name',
        'playground',
    )
    list_filter = ('game_name',)
    search_fields = (
        'student__name',
        'student__roll_number',
        'game_name',
    )



@admin.register(StudentDocument)
class StudentDocumentAdmin(LeafletGeoAdmin):
    list_display = (
        'id',
        'student',
        'document_name',
        'document',
    )
    list_filter = ('student__name',)
    search_fields = (
        'student__name',
        'student__roll_number',
        'document_name',
    )

