from django.contrib import admin
from django.urls import path,include
from rest_framework.routers import DefaultRouter
from django.conf.urls.static import static
from django.conf import settings


from .views import (StudentViewSet,StudentMarksViewSet,StudentLocationViewSet,StudentBusRouteViewSet,StudentPlaygroundViewSet,
                    CameraAPIView,)

router = DefaultRouter()

router.register(r'students',StudentViewSet,basename='student')
router.register(r'marks',StudentMarksViewSet,basename='student-marks')
router.register(r'locations',StudentLocationViewSet,basename='student-location')
router.register(r'bus-routes',StudentBusRouteViewSet,basename='student-bus-route')
router.register(r'playgrounds',StudentPlaygroundViewSet,basename='student-playground')


urlpatterns = router.urls

# urlpatterns = [
#     # path('admin/', admin.site.urls),
#
# ]

urlpatterns = [
    path('', include(router.urls)),

]

if settings.DEBUG:
    urlpatterns = urlpatterns + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
    urlpatterns = urlpatterns + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)



