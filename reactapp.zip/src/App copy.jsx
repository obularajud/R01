import React,{ useState,createContext } from 'react'
import heroImg from './assets/hero.png'
import reactLogo from './assets/react.svg'
import viteLogo from './assets/vite.svg'
import './App.css'
// import { BrowserRouter as Router, Route, Switch, Redirect,} from 'react-router-dom';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Component from "./views/Component";
import Propex from "./views/Propex";
import ClassTest from "./views/ClassTest";
import ClassTestProp from "./views/ClassTestProp";
import FunuseState from "./views/FunuseState";
import FunProp from "./views/FunProp";
import Event from "./views/Event";
import Form from "./views/Form";
import Pathparam from "./views/Pathparam"
import Queryparam from "./views/Queryparam"
import Pagenotfound from "./views/Pagenotfound";
import ComponentA from './views/ComponentA'
import ComponentB from './views/ComponentB'

import ComponentC from './views/ComponentC'
import ComponentD from './views/ComponentD'
import ComponentE from './views/ComponentE'
import ComponentF from './views/ComponentF'


import { AuthProvider } from './context/AuthContext'

export const store=createContext();
export const store02=createContext();

function App() {
  const [count, setCount] = useState(0);
  const [data,setData]=useState(0);
  
  const [data01,setData01]=useState([
    {
      brandname:'Nokia'
    },
    {
      brandname:'Realme'
    },
    {
      brandname:'Mi'
    }
  ]);

  return (
    <>

    <BrowserRouter>

          <store.Provider value={[data,setData]}>
          <store02.Provider value={[data01,setData01]}>            

          <AuthProvider>

          <Routes>
          <Route path="/" element={<Component />} />
          <Route path="/Propex/" element={<Propex name='Ravi' />} />
          <Route path="/classtest/" element={<ClassTest />} />
          <Route path="/classtestprop/" element={<ClassTestProp name={"Ravi"} age={30} />} />
          <Route path="/funusestate/" element={<FunuseState />} />
          <Route path="/funprop/" element={<FunProp name='Ravi' age={30}/>} />
          <Route path="/event/" element={<Event />} />
          <Route path="/form/" element={<Form />} />          
          <Route path="/pathparam/:name" element={<Pathparam />} />
          <Route path="/queryparam/" element={<Queryparam />} />                              
          <Route path="/componentA/" element={
            <>
            <ComponentA /> 
            <ComponentB />
            </>
            }
            />          
          <Route path="/componentB/" element={<ComponentB />} />                   
          <Route path="/componentC/" element={
            <>
            <ComponentC /> 
            <ComponentD />
            </>
            }
          />                   
          
          <Route path="/componentE/" element={<ComponentE />} />
          <Route path="/ComponentF/" element={<ComponentF />} />
          


          {/* 404 Page */}
          <Route
                    path="*"
                    element={<Pagenotfound />}
                />


          </Routes>

          </AuthProvider>
              </store02.Provider>              
              </store.Provider>


    </BrowserRouter>

    </>
  )
}

export default App

// ES7+ React/Redux/React-Native Snippets
// Provides shortcuts like rafce, rfc, etc.

// Prettier - Code formatter