import React, { useContext } from 'react';
import { store02 } from '../App';

const ComponentC = () => {
  const [data01] = useContext(store02);

  return (
    <>
      <div>ComponentC</div>

      <center>
        <div className='col-6'>

      <div className="card">
        <div className="card-body">

          {data01.map((item, index) => (
            <h3 key={index} className="card-title">
              {item.brandname}
            </h3>
          ))}

        </div>
      </div>
      </div>
      </center>

    </>
  );
};

export default ComponentC;