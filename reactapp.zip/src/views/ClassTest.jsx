import React, { Component } from 'react'

class ClassTest extends Component {

  state = {
    name: 'Ravi',
    age: 25,
    data: []
  }

  render() {
    return (
      <div>
        ClassTest {this.state.name} <br/>
        {this.state.age}
        
      </div>
    )
  }
}

export default ClassTest
