import React,{useState} from 'react'

const Event = () => {
    const [name,setName]=useState('');
  return (
    
    <>
    <div>Event</div>
   
   <center>
        <button onClick={()=> alert("Hello")}>Click Me</button><br/>
        Name : {name} <br/>
        <input type="text" name="name" onChange={(e)=> setName(e.target.value)} />
   </center>
    
    </>
  )
}

export default Event