import React, { useContext, useEffect, useState } from 'react';
import AuthContext from '../context/AuthContext';

const ComponentE = () => {

  const { getstudentname } = useContext(AuthContext);

  const [orgdata, setOrgdata] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      const data = await getstudentname();
      console.log(data);
      setOrgdata(data);
    };
    fetchData();

  }, []);

  return (
    <>
      <div>ComponentE</div>

      <h3>Student Data</h3>

      <pre>
        {JSON.stringify(orgdata, null, 2)}

        <center>
        <table border="1" cellPadding="10">
          <thead>
            <tr>
              <th style={{ border: "1px solid black" }}>ID</th>
              <th style={{ border: "1px solid black" }}>Name</th>
              <th style={{ border: "1px solid black" }}>Roll Number</th>
              <th style={{ border: "1px solid black" }}>Photo</th>
            </tr>
          </thead>

          <tbody>
            {orgdata.map((element) => (
              <tr key={element.id}>
                <td style={{ border: "1px solid black" }}>{element.id}</td>
                <td style={{ border: "1px solid black" }}>{element.name}</td>
                <td style={{ border: "1px solid black" }}>{element.roll_number}</td>
                <td style={{ border: "1px solid black" }}>
                  <img
                    src={element.photo}
                    alt={element.name}
                    width="80"
                  />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        </center>

      
      </pre>
    </>
  );
};

export default ComponentE;