import React from 'react'
import { useParams } from 'react-router-dom';

const Pathparam = () => {
    let params=useParams();
  return (
    <>

    <div>Pathparam</div>
    name : {params.name}
    </>
  )
}

export default Pathparam

// path
// <Route path='/dashboard/:name' />
// <Link to='dashboard/john' />

// Query :
// <Route path='/dashboard' />
// <Link to='dashboard?name=ravi'/>
