import React, { useState } from 'react';
import {Link} from 'react-router-dom'
import '../index.css'

const Form = () => {

  const [data, setData] = useState({
    email: '',
    password: ''
  });

  const changeHandler = (e) => {
    setData({
      ...data,
      [e.target.name]: e.target.value
    });
  };

  const submitHandler = (e) => {
    e.preventDefault();
    console.log(data);
  };

  return (
    <div>
      Form

      <center>
        <form
          onSubmit={submitHandler}
          style={{
            color: 'red',
            border: '2px solid black',
            padding: '20px',
            width: '300px'
          }}
        >

          <label>Email</label>
          <br />

          <input
            type="text"
            name="email"
            value={data.email}
            onChange={changeHandler}
          />

          <br />

          <label>Password:</label>
          <br />

          <input
            type="password"
            name="password"
            value={data.password}
            onChange={changeHandler}
          />

          <br />

          <input
            type="submit"
            value="Login"
          />

        </form>
      </center>
      <br />

      <Link to='/' className='Link'>Back to Home</Link>

    </div>
  );
};

export default Form;