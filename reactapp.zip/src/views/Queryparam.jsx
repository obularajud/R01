import React from 'react'
import { useLocation } from 'react-router-dom'
const Queryparam = () => {
    let { search } =useLocation();
    let params=new URLSearchParams(search);
    console.log(search);

  return (
    <>
    <div>Queryparam</div>
    name :{params.get('name')}<br/>
    age :{params.get('age')}<br/>
    </>
  )
}

export default Queryparam

// http://localhost:5173/queryparam/?name=%22ravi%22&age=23