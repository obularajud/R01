// rafce
import React,{ useState } from 'react'

const FunuseState = () => {
    const [name01,setName01]=useState('Ravi');
    const [data,setDate]=useState({
        name:'Ravi',
        age:30
    });

    const {name,age}=data;


    return (
        <>
    <div>Fun prop { name01 } </div>
    <div>Fun prop { data.name } </div>
    <div>name : {name} ,And age : { age } </div>

    </>
  )
}

export default FunuseState