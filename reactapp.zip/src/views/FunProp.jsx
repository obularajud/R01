// rafce
import React,{ useState } from 'react'

const FunProp = (props) => {

    return (
        <>
        <div>name : {props.name} ,And age : { props.age } </div>
    </>
  )
}

export default FunProp
