import React, { useContext, useState } from 'react';
import { store02 } from '../App';

const ComponentD = () => {

  const [data01, setData01] = useContext(store02);

  const [name, setName] = useState('');

  const submitHandler = (e) => {
    e.preventDefault();

    setData01([
      ...data01,
      { brandname: name }
    ]);

    setName('');
  };

  return (
    <>
      <div>ComponentD</div>

      <center>
        <div className="col-6">

          <div className="card">
            <div className="card-body">

              {data01.map((item, index) => (
                <h3 key={index} className="card-title">
                  {item.brandname}
                </h3>
              ))}

              <form onSubmit={submitHandler}>

                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Enter"
                />

                <input
                  type="submit"
                  value="Add"
                />

              </form>

            </div>
          </div>

        </div>
      </center>
    </>
  );
};

export default ComponentD;