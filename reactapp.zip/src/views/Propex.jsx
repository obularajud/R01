import React from 'react'

const Propex = (props) => {
  console.log(props.name);

  const numbers = [];
  let c=0;

  for(let i = 1; i <= 5; i++) {
    numbers.push(<div key={i}>{i}</div>);
  }

  let sub=(a,b)=>{
    console.log(a-b);
    return a-b;
  };

  const add=(a,b)=>{
    console.log(a+b);
    return a+b;
  };

  c= add(2, 5);
  let d=sub(2,5);

// Variable Declaration

  var data=1.5;
  var name='Ravi';
  var booldata=true;
  var data02;
// Data Types
  console.log(typeof c);
    console.log(typeof data);
    console.log(typeof name);
    console.log(typeof booldata);
    console.log(typeof data02);

// Array and Objects
  var data03=[1,2,3,4,5];
  console.log(typeof data03);
  console.log(data03[0],data03[1],data03[2]);



  var data04 ={
    name:'Ravi',
    age:28,
    Location:'HYD'
  }
  console.log(typeof data04);
  console.log(data04,data04.name,data04.Location);

  // Functions 


  function user(){
    //block code
    console.log('fun call')
  }
  user()
    
  function user(num1){
    //block code
    console.log('fun value',num1)
  }
  user(10);

  function fun01(num1){
    //block code
    console.log('fun01 value',num1)
    return num1
  }
  var newvalue=fun01(10);
  console.log(newvalue);

// Conditional Statement  
  //condt if if-else 
  //  var marks=80;
  // if(Condition){
  //   //block of code
  // } 
  var marks=80;
  if(marks>80){
    console.log('Grade A');
    //block of code
  } 
  else{
    console.log('Condt Grade B');
  }

  var marks=80;
  if(marks>80){
    console.log('Grade A');
    //block of code
  }
  else if(marks>55){
  console.log('Grade B');
  } 
  else{
    console.log('Condt Grade C');
  }  
 //Looping Concept
 // for while
//  for(Statement01;Statement02;Statement03){}
// for(variable_declaration;condition;inc/dec){
//   //block code
// }

for(var i=1;i<5;i++){
  console.log('hello',i);
}

var sum=0;
for(var i=1;i<5;i++){
  console.log('hello',i);
  sum=sum+i;
}
console.log(sum);

var sum01=0;
while(sum01<=5){
  console.log('hello',i);
  sum01++;
}
console.log('While Loop',sum01);

// ES05

// array Features 

// isArray()
// map()
// filter()
// forEach()
// every()
// some()
// indexOf()
// lastIndexOf()

// isArray()
var data=[1,2,3,4]
console.log(Array.isArray(data));

var data=1
console.log(Array.isArray(data));

// map()
var data =[1,2,3,4]
data.map(function(element)  {
  console.log('map',element);
}
)

var data =[1,2,3,4]
var output = data.map(function(element)  {
  return element+1;
}
)
console.log(output)

// filter()
var data =[1,2,3,4]
var output = data.filter(function(element)  {
  return element>2;
}
)
console.log('filter',output)

// forEach()
var data =[1,2,3,4]
data.forEach(function(element)  {
  console.log('forEach',element);
}
)

// every() all conditions True then return True
var data =[1,2,3,4]
var output = data.every(function(element)  {
  return element>2;
}
)

console.log('every',output)

// some()  any one Cont True
var data =[1,2,3,4]
var output = data.some(function(element)  {
  return element>2;
}
)

console.log('some',output)
// indexOf() spafic value index 
var data =[1,2,3,4]
console.log('indexOf',data.indexOf(4))

// lastIndexOf()
var data =[1,2,3,4,5,6,4,8]
console.log('lastIndexOf',data.lastIndexOf(4))


// Json Features 
// stringify()
var data ={
  name:'John',
  age:28
}
var json=JSON.stringify(data);
console.log('json',json);


//OOPS

  class Student {
      constructor(name, age) {
          this.name = name;
          this.age = age;
      }

      display() {
          console.log(this.name);
          console.log(this.age);
      }
  }

  let s1 = new Student("Ravi", 25);

  s1.display();


// Inheritance extends
class Student01 {
    display() {
        console.log("I am a student");
    }
}

class CollegeStudent extends Student01 {
    show() {
        console.log("I am a college student");
    }
}

let s2 = new CollegeStudent();

s2.display();
s2.show();



class Student02 {
    #marks;

    constructor(name, marks) {
        this.name = name;
        this.#marks = marks;
    }

    getMarks() {
        return this.#marks;
    }

    setMarks(marks) {
        if (marks >= 0 && marks <= 100) {
            this.#marks = marks;
        }
    }
}

const student02 = new Student02("Ravi", 85);

console.log(student02.name);       // Ravi
console.log(student02.getMarks()); // 85
student02.setMarks(90);
console.log(student02.getMarks()); // 90


// Date Features
// valueOf()


// ES6 / ECMAScript 2015
// Let & Const
// Arrow Function 
// Classes 
// For ..of
// Default Parameter
// Rest Operator 
// Spread Operator 
// Destructuring 

// Let & Const
{
  var data=10;
}
console.log(data);



{
  let l01=10;
}
// console.log(l01);
// Propex.jsx:236 Uncaught ReferenceError: l01 is not defined
//     at Propex (Propex.jsx:236:13)

// @react-refresh:231 An error occurred in the <Pr

{
  let l01=10;
console.log(l01);
}
// Const

// case 01

// const c02=10;
// c02=20;
// console.log(c02);

// Propex.jsx:249 Uncaught TypeError: Assignment to constant variable.

// case 02
const c03=10;
console.log(c03);

// Arrow Function 
const user001 = () => console.log('hello');
user001();

const user002 = (num1) => {return num1+5;}
var output=user002(10);
console.log(user002(10));


// Classes 
class User002{
admin(){
  console.log('From admin method');
}
}
let obj=new User002();
obj.admin();

// Classes 
class User003{
constructor(msg){
this.msg=msg;
}
  admin(){
  console.log('From admin method',this.msg);
}
}
let obj01=new User003('Hi');
obj01.admin();
let obj02=new User003('Hello');
obj02.admin();

// For ..of
const arr=[1,2,3,4,5];
for(const a of arr){
  console.log(a);
}
// Default Parameter
function user05(name){
  console.log(name);
}
user('John')


function user05(name,age=20){
  console.log(name,age);
}
user05('John',25)
user05('John')


// Rest Operator 
// remaining is any name

function user06(name,...remaining){
  console.log(name,remaining);
}
user06('John',25)
user06('John')
user06('John',25,'mail@gmail.com',12345)
//rest = rest of values(remainig)


// Spread Operator 
let arr1=[1,2,3,4,5];
let arr2=[6,7,8,9,10];
let arr3=[...arr1,...arr2];
console.log(arr3);
// Destructuring 

let person01={
  name01:'John',
  age01:25,
  mail01:'john@gmail.com'
}
// console.log(person.name);
// const [name01,age01,mail01]=person01;
// Uncaught TypeError: person01 is not iterable
// const {name01,age01,mail01}=person01;
const {name01,age01,mail01}=person01;

console.log('Destructuring',name01);


return (
    <>
    <div>Propex {props.name}</div>
    <div>{ numbers }</div>
    <div>{ c }</div>
    <div>{ d }</div>
    

    </>
  )
}

export default Propex