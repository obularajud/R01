import { useState } from "react";

const Component = () => {
const name='Ravi';

const [count,SetCount]=useState(0);

  return (
    <>
      <br />
      <br />
      <br />
      <br />
      <div>Component {name}</div>
      <div>Component {count}</div>
      <div>Component</div>
      <div>Component</div>
    </>
  );
};

export default Component;