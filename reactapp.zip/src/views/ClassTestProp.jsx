import React, { Component } from 'react'

class ClassTestProp extends Component {

  render() {
    return (
      <div>
        ClassTestProp {this.props.name} <br/>
        {this.props.age}
        
      </div>
    )
  }
}

export default ClassTestProp
