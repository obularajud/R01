// rafce
import React,{useContext} from 'react'
import {store} from '../App'; 

const ComponentA = () => {
   const [data,setData]=useContext(store);

    return (
        <>
    <div>ComponentA {data}</div>
    <center>
    <button onClick={()=>setData(data+1)}>Increment</button>
    <button onClick={()=>setData(data-1)}>Decrement</button>
    </center>

        </>
  )
}

export default ComponentA