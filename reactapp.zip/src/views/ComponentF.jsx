import React, { useContext, useEffect, useState } from 'react';
import AuthContext from '../context/AuthContext';

import {
  MapContainer,
  TileLayer,
  Marker,
  Popup,
  GeoJSON
} from 'react-leaflet';

import 'leaflet/dist/leaflet.css';

const ComponentF = () => {





  const {
    getstudentname,
    getStudentLocations,
    getBusRoutes,
    getPlaygrounds
  } = useContext(AuthContext);


  // Student data
  const [orgdata, setOrgdata] = useState([]);

  // Map data
  const [locations, setLocations] = useState(null);
  const [busRoutes, setBusRoutes] = useState(null);
  const [playgrounds, setPlaygrounds] = useState(null);


  useEffect(() => {

    const fetchData = async () => {

      const students = await getstudentname();
      const locationData = await getStudentLocations();
      const routeData = await getBusRoutes();
      const playgroundData = await getPlaygrounds();


      console.log("Students:", students);
      console.log("Locations:", locationData);
      console.log("Bus Routes:", routeData);
      console.log("Playgrounds:", playgroundData);


      setOrgdata(students);
      setLocations(locationData);
      setBusRoutes(routeData);
      setPlaygrounds(playgroundData);

    };

    fetchData();

  }, []);


  return (
    <>

      <div>ComponentF</div>


      {/* ================= LEAFLET MAP ================= */}

      <h3>Student Map</h3>


      <MapContainer
        center={[17.55, 78.43]}
        zoom={11}
        style={{
          height: "600px",
          width: "100%"
        }}
      >

        {/* OpenStreetMap */}

        <TileLayer
          attribution='&copy; OpenStreetMap contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />


        {/* ================= STUDENT LOCATIONS ================= */}

        {locations && (

          <GeoJSON
            data={locations}
            onEachFeature={(feature, layer) => {

              layer.bindPopup(
                `Student ID: ${feature.properties.student}`
              );

            }}
          />

        )}


        {/* ================= BUS ROUTES ================= */}

        {busRoutes && (

          <GeoJSON
            data={busRoutes}
            onEachFeature={(feature, layer) => {

              layer.bindPopup(
                `Student ID: ${feature.properties.student}
                 <br/>
                 Bus Number: ${feature.properties.bus_number}`
              );

            }}
          />

        )}


        {/* ================= PLAYGROUNDS ================= */}

        {playgrounds && (

          <GeoJSON
            data={playgrounds}
            onEachFeature={(feature, layer) => {

              layer.bindPopup(
                `Student ID: ${feature.properties.student}
                 <br/>
                 Game: ${feature.properties.game_name}`
              );

            }}
          />

        )}

      </MapContainer>
        <br/>


      <h3>Student Data</h3>


      {/* ================= STUDENT TABLE ================= */}

      <table
        border="1"
        cellPadding="10"
        style={{
          borderCollapse: "collapse",
          margin: "20px auto"
        }}
      >

        <thead>

          <tr>

            <th style={{ border: "1px solid black" }}>ID</th>

            <th style={{ border: "1px solid black" }}>Name</th>

            <th style={{ border: "1px solid black" }}>Roll Number</th>

            <th style={{ border: "1px solid black" }}>Photo</th>

          </tr>

        </thead>


        <tbody>

          {orgdata.map((element) => (

            <tr key={element.id}>

              <td style={{ border: "1px solid black" }}>{element.id}</td>

              <td style={{ border: "1px solid black" }}>{element.name}</td>
              <td style={{ border: "1px solid black" }}>{element.roll_number}</td>
              <td style={{ border: "1px solid black" }}>
                <img
                  src={element.photo}
                  alt={element.name}
                  width="80"
                />

              </td>

            </tr>

          ))}

        </tbody>

      </table>

    </>

  );

};

export default ComponentF;