import React,{ useState,createContext } from 'react'
import { BrowserRouter, Routes, Route } from "react-router-dom";

import Component from "./views/Component";
import ClassTest from "./views/ClassTest";

function App() {

  return (
    <>

    <BrowserRouter>
          <Routes>
            <Route path="/" element={<Component />} />
            <Route path="/classtest/" element={<ClassTest />} />


            {/* 404 Page */}
            <Route
                      path="*"
                      element={<Pagenotfound />}
                  />


            </Routes>
    </BrowserRouter>
    </>
  )
}

export default App

// ES7+ React/Redux/React-Native Snippets
// Provides shortcuts like rafce, rfc, etc.

// Prettier - Code formatter