import {createContext, useState, useEffect} from "react";
import jwt_decode from "jwt-decode";
import {useHistory} from "react-router-dom";
import Cookies from "js-cookie"; // Import js-cookie
import axios from "axios";

const swal = require('sweetalert2')


const AuthContext = createContext();

export default AuthContext

export const AuthProvider = ({ children }) => {
    

    const [user, setUser] = useState(() => 
        localStorage.getItem("username")
            ? localStorage.getItem("username")
            : null
    );


    const [loading, setLoading] = useState(true);
    const [aid, setaid] = useState(null);

    const history = useHistory();
    const [position, setPosition] = useState(null);

    useEffect(() => {
      // Use navigator.geolocation to get the user's location
      navigator.geolocation.getCurrentPosition(
        (location) => {
          const { latitude, longitude } = location.coords;
          setPosition([latitude, longitude]);
          // mapRef.flyTo([latitude, longitude], mapRef.getZoom());
          // localStorage.setItem("latitude", latitude)
          // localStorage.setItem("longitude", longitude)
  
          // setCenter([latitude, longitude]); // Set the center coordinates
  
        },
        (error) => {
          console.error('Error getting user location:', error);
        }
      );
    }, []);


    
    const loginUser = async (username, password) => {
        console.log(username,password);
        const apiUrl = "http://192.168.1.160:7007/api/userdata/login/";        
        //const apiUrl = "/api/land/login/";

        const response = await fetch(apiUrl, {
            method: "POST",
            headers:{
                "Content-Type":"application/json",
                "X-CSRFToken":Cookies.get('csrftoken')
              },
            body: JSON.stringify({
                username, password
            })
        })
        const data = await response.json()
        console.log(data);

        if(response.status === 200){
            console.log("Logged In");
            setUser(data.username)
            localStorage.setItem("username", data.username)
            localStorage.setItem("password", password)
            localStorage.setItem("authenticated", JSON.stringify(data.token))
            history.push("/")
            swal.fire({
                title: "Login Successful",
                icon: "success",
                toast: true,
                timer: 6000,
                position: 'top-right',
                timerProgressBar: true,
                showConfirmButton: false,
            })

        } else {    
            console.log(response.status);
            console.log("there was a server issue");
            swal.fire({
                title: "Username or passowrd does not exists",
                icon: "error",
                toast: true,
                timer: 6000,
                position: 'top-right',
                timerProgressBar: true,
                showConfirmButton: false,
            })
        }
    }



    
    

    const registerUser = async (email, username, password, password2) => {
       const apiUrl = "http://192.168.1.160:7007/api/userdata/register/";
      //const apiUrl = "/api/land/register/";
      
      const response = await fetch(apiUrl, {
            method: "POST",
            headers: {
                "Content-Type":"application/json",
                "X-CSRFToken":Cookies.get('csrftoken')
              },
            body: JSON.stringify({
                email, username, password, password2
            })
        })
        if(response.status === 201){
            history.push("/login")
            swal.fire({
                title: "Registration Successful, Login Now",
                icon: "success",
                toast: true,
                timer: 6000,
                position: 'top-right',
                timerProgressBar: true,
                showConfirmButton: false,
            })
        } else {
            console.log(response.status);
            console.log("there was a server issue");
            swal.fire({
                title: "An Error Occured " + response.status,
                icon: "error",
                toast: true,
                timer: 6000,
                position: 'top-right',
                timerProgressBar: true,
                showConfirmButton: false,
            })
        }
    }

    const logoutUser = async () => {
        setUser(null)
        localStorage.removeItem("username")
        localStorage.removeItem("password")
        localStorage.removeItem("authenticated")        

        try {
           const apiUrl = "http://192.168.1.160:7007/api/userdata/logout/";
       //   const apiUrl = "/api/land/logout/";          
          const response = await fetch(apiUrl, {
            method: "GET",
            headers: {
              "Content-Type": "application/json",
              "X-CSRFToken":Cookies.get('csrftoken')
            }
          });
    
          const jsonData = await response.json();
          console.log(jsonData);
    
          if (response.status === 200) {
            console.log("Logged Out");
            // drawChart(jsonData);
          } else {
            console.log(response.status);
            console.log("There was a server issue");
          }
        } catch (error) {
          console.error("An error occurred:", error);
        }
    
        
        history.push("/login")
        swal.fire({
            title: "YOu have been logged out...",
            icon: "success",
            toast: true,
            timer: 6000,
            position: 'top-right',
            timerProgressBar: true,
            showConfirmButton: false,
        })
    }



const getnestedland = async (username, password,id) => {
  const apiUrl01 = `http://192.168.1.160:7007/api/land/fmblist/getnestedland/?landid=${id}`;
                    
  try {
    const response = await fetch(apiUrl01, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Basic ${btoa(`${username}:${password}`)}`,
        "X-CSRFToken":Cookies.get('csrftoken')
      }
    });

    const jsonData = await response.json();
    if (response.status === 200) {
      return jsonData;
    } else {
      console.log(response.status);
      console.log("There was a server issue");
    }
  } catch (error) {
    console.error("An error occurred:", error);
  }
};


const getnestedlandgis = async (username, password,id) => {
  const apiUrl01 = `http://192.168.1.160:7007/api/nestedland/commentsgis/?id__in=${id}`;
                    
  try {
    const response = await fetch(apiUrl01, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Basic ${btoa(`${username}:${password}`)}`,
        "X-CSRFToken":Cookies.get('csrftoken')
      }
    });

    const jsonData = await response.json();
    if (response.status === 200) {
      return jsonData;
    } else {
      console.log(response.status);
      console.log("There was a server issue");
    }
  } catch (error) {
    console.error("An error occurred:", error);
  }
};


const getadangallinkgis = async (username, password) => {
  const apiUrl01 = `http://192.168.1.160:7007/api/adangallink/`;
                    
  try {
    const response = await fetch(apiUrl01, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Basic ${btoa(`${username}:${password}`)}`,
        "X-CSRFToken":Cookies.get('csrftoken')
      }
    });

    const jsonData = await response.json();
    if (response.status === 200) {
      return jsonData;
    } else {
      console.log(response.status);
      console.log("There was a server issue");
    }
  } catch (error) {
    console.error("An error occurred:", error);
  }
};


const getadangalfmbpolygonlinkgis = async (username, password) => {
  const apiUrl01 = `http://192.168.1.160:7007/api/adangallink/adangalfmbpolygonlink/`;
                    
  try {
    const response = await fetch(apiUrl01, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Basic ${btoa(`${username}:${password}`)}`,
        "X-CSRFToken":Cookies.get('csrftoken')
      }
    });

    const jsonData = await response.json();
    if (response.status === 200) {
      return jsonData;
    } else {
      console.log(response.status);
      console.log("There was a server issue");
    }
  } catch (error) {
    console.error("An error occurred:", error);
  }
};


const getuniqueuniquekhata = async (username, password) => {
  const apiUrl01 = `http://192.168.1.160:7007/api/adangallink/uniqueuniquekhata/`;
                    
  try {
    const response = await fetch(apiUrl01, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Basic ${btoa(`${username}:${password}`)}`,
        "X-CSRFToken":Cookies.get('csrftoken')
      }
    });

    const jsonData = await response.json();
    if (response.status === 200) {
      return jsonData;
    } else {
      console.log(response.status);
      console.log("There was a server issue");
    }
  } catch (error) {
    console.error("An error occurred:", error);
  }
};


const getfmblinkgis = async (username, password) => {
  const apiUrl01 = `http://192.168.1.160:7007/api/fmblink/`;
                    
  try {
    const response = await fetch(apiUrl01, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Basic ${btoa(`${username}:${password}`)}`,
        "X-CSRFToken":Cookies.get('csrftoken')
      }
    });

    const jsonData = await response.json();
    if (response.status === 200) {
      return jsonData;
    } else {
      console.log(response.status);
      console.log("There was a server issue");
    }
  } catch (error) {
    console.error("An error occurred:", error);
  }
};


const getadangalfmbpolygonkatanumberlink = async (username, password,katanumber) => {
 
  const apiUrl01 = `http://192.168.1.160:7007/api/adangallink/adangalfmbpolygonkatanumberlink/?katanumber=[${katanumber}]`;; 

  try {
    const response = await fetch(apiUrl01, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Basic ${btoa(`${username}:${password}`)}`,
        "X-CSRFToken":Cookies.get('csrftoken')
      }
    });

    const jsonData = await response.json();
    if (response.status === 200) {
      return jsonData;
    } else {
      console.log(response.status);
      console.log("There was a server issue");
    }
  } catch (error) {
    console.error("An error occurred:", error);
  }
};  


const getadangalpolygonkatanumberlink = async (username, password, katanumber) => {
   const apiUrl01 = `http://192.168.1.160:7007/api/adangallink/adangalpolygonkatanumberlink/?katanumber=[${katanumber}]`; 

  try {
    const response = await fetch(apiUrl01, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Basic ${btoa(`${username}:${password}`)}`,
        "X-CSRFToken":Cookies.get('csrftoken')
      }
    });

    const jsonData = await response.json();
    if (response.status === 200) {
      return jsonData;
    } else {
      console.log(response.status);
      console.log("There was a server issue");
    }
  } catch (error) {
    console.error("An error occurred:", error);
  }
};  


const getagricalturelogreport = async (username, password, madangal) => {
  const apiUrl01 = `http://192.168.1.160:7007/api/agricalturelogreport/?madangal=${madangal}`; 

 try {
   const response = await fetch(apiUrl01, {
     method: "GET",
     headers: {
       "Content-Type": "application/json",
       Authorization: `Basic ${btoa(`${username}:${password}`)}`,
       "X-CSRFToken":Cookies.get('csrftoken')
     }
   });

   const jsonData = await response.json();
   if (response.status === 200) {
     return jsonData;
   } else {
     console.log(response.status);
     console.log("There was a server issue");
   }
 } catch (error) {
   console.error("An error occurred:", error);
 }
};  

//http://192.168.1.160:7007/api/landwork/?madangal=13
const getlandwork = async (username, password, madangal) => {
  const apiUrl01 = `http://192.168.1.160:7007/api/landwork/?madangal=${madangal}`; 

 try {
   const response = await fetch(apiUrl01, {
     method: "GET",
     headers: {
       "Content-Type": "application/json",
       Authorization: `Basic ${btoa(`${username}:${password}`)}`,
       "X-CSRFToken":Cookies.get('csrftoken')
     }
   });

   const jsonData = await response.json();
   if (response.status === 200) {
     return jsonData;
   } else {
     console.log(response.status);
     console.log("There was a server issue");
   }
 } catch (error) {
   console.error("An error occurred:", error);
 }
};  

//http://192.168.1.160:7007/api/fmblandsaledata/

const getfmblandsaledata = async (username, password) => {
  const apiUrl01 = `http://192.168.1.160:7007/api/fmblandsaledata/`; 

 try {
   const response = await fetch(apiUrl01, {
     method: "GET",
     headers: {
       "Content-Type": "application/json",
       Authorization: `Basic ${btoa(`${username}:${password}`)}`,
       "X-CSRFToken":Cookies.get('csrftoken')
     }
   });

   const jsonData = await response.json();
   if (response.status === 200) {
     return jsonData;
   } else {
     console.log(response.status);
     console.log("There was a server issue");
   }
 } catch (error) {
   console.error("An error occurred:", error);
 }
};  



  const contextData = {
        user, 
        setUser,
        registerUser,
        loginUser,
        logoutUser,

        //160(7007) land nested 
        getnestedland,
        getnestedlandgis,




        getadangallinkgis,
        getfmblinkgis,        
        getadangalfmbpolygonlinkgis,
        getuniqueuniquekhata,
        getadangalfmbpolygonkatanumberlink,
        getadangalpolygonkatanumberlink,
        getagricalturelogreport,
        getlandwork,
        getfmblandsaledata,
        
        
        // Add your dictionary here
        djangoserver: {
          //networkurl: 'http://127.0.0.1:8000',
           networkurl: '',
        },

      }


    useEffect(() => {
        if (user) {
            setUser(localStorage.getItem("username").replace(/^"(.*)"$/, '$1'))
        }
        setLoading(false)
        // endAdangaldataid('giri', 'abcd1234',13)
        
    }, [user, loading])

    return (
        <AuthContext.Provider value={contextData}>
            {loading ? null : children}
        </AuthContext.Provider>
    )
}
