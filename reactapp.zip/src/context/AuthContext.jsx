import { createContext, useState, useEffect } from "react";
import Cookies from "js-cookie";

const AuthContext = createContext();

export default AuthContext;

export const AuthProvider = ({ children }) => {

    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(true);

    const getstudentname = async () => {
        const apiUrl01 = "http://127.0.0.1:8000/student/students/";

        try {
            const response = await fetch(apiUrl01, {
                method: "GET",
                headers: {
                    "Content-Type": "application/json",
                }
            });

            const jsonData = await response.json();

            if (response.status === 200) {
                return jsonData;
            } else {
                console.log(response.status);
                console.log("There was a server issue");
            }

        } catch (error) {
            console.error("An error occurred:", error);
        }
    };



    // Student Locations
    const getStudentLocations = async () => {

        const response = await fetch(
            "http://127.0.0.1:8000/student/locations/"
        );

        return await response.json();
    };


    // Bus Routes
    const getBusRoutes = async () => {

        const response = await fetch(
            "http://127.0.0.1:8000/student/bus-routes/"
        );

        return await response.json();
    };


    // Playgrounds
    const getPlaygrounds = async () => {

        const response = await fetch(
            "http://127.0.0.1:8000/student/playgrounds/?format=json"
        );

        return await response.json();
    };

    const contextData = {
        getstudentname,

        getStudentLocations,
        getBusRoutes,
        getPlaygrounds,
        
      };

    useEffect(() => {

        const username = localStorage.getItem("username");

        if (username) {
            setUser(username.replace(/^"(.*)"$/, "$1"));
        }

        setLoading(false);

    }, []);

    return (
        <AuthContext.Provider value={contextData}>
            {loading ? null : children}
        </AuthContext.Provider>
    );
};